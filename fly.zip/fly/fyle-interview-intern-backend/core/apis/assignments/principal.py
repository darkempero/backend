from flask import Blueprint,jsonify
from core import db
from core.apis import decorators
from core.apis.responses import APIResponse
from core.models import teachers
from core.models.assignments import Assignment
from marshmallow import ValidationError

from .schema import AssignmentSchema, AssignmentGradeSchema
principal_assignments_resources = Blueprint('principal_assignments_resources', __name__)

@principal_assignments_resources.route('/assignments', methods=['GET'], strict_slashes=False)
@decorators.authenticate_principal
def listallassignments(p):
  
  principal_assignments= Assignment.get_assignments_by_principal()
  principal_assignments_dump = AssignmentSchema().dump(principal_assignments, many=True)
  return APIResponse.respond(data=principal_assignments_dump)


@principal_assignments_resources.route('/assignments/grade', methods=['POST'], strict_slashes=False)
@decorators.authenticate_principal
@decorators.accept_payload
def gradebyprincipal(p, incoming_payload):
    try:
        grade_assignment_payload = AssignmentGradeSchema().load(incoming_payload)
    except ValidationError as err:
        return APIResponse.respond(data={"error": err.messages}), 400
    
    try:
        principal_assignments = Assignment.mark_grade_principal(
            _id=grade_assignment_payload.id,
            grade=grade_assignment_payload.grade,
            auth_principal=p  # Passing the principal for authentication
        )
        db.session.commit()
        principal_assignments_dump = AssignmentSchema().dump(principal_assignments)
        return APIResponse.respond(data=principal_assignments_dump)
    except AssertionError as e:
        return APIResponse.respond(data={"error": str(e)}), 400

@principal_assignments_resources.route('/teachers', methods=['GET'], strict_slashes=False)
@decorators.authenticate_principal
def get_teacher_ids(p):
    """Retrieves all teacher IDs."""
    all_teach=Assignment.getTeach()
    
    return APIResponse.respond(data=all_teach)

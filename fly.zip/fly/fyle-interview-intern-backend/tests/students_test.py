def test_get_assignments_student_1(client, h_student_1):
    response = client.get(
        '/student/assignments',
        headers=h_student_1
    )

    assert response.status_code == 200

    data = response.json['data']
    for assignment in data:
        assert assignment['student_id'] == 1


def test_get_assignments_student_2(client, h_student_2):
    response = client.get(
        '/student/assignments',
        headers=h_student_2
    )

    assert response.status_code == 200

    data = response.json['data']
    for assignment in data:
        assert assignment['student_id'] == 2


def test_post_assignment_null_content(client, h_student_1):
    """
    failure case: content cannot be null
    """
    
    response = client.post(
        '/student/assignments',
        headers=h_student_1,
        json={
            'id':1,

            'content': None,
            'teacher':2
        })

    assert response.status_code == 400


def test_post_assignment_student_1(client, h_student_1):
    content = 'ABCD TESTPOST'

    response = client.post(
        '/student/assignments',
        headers=h_student_1,
        json={
            'content': content
        })

    assert response.status_code == 200

    data = response.json['data']
    assert data['content'] == content
    assert data['state'] == 'DRAFT'
    assert data['teacher_id'] is None


def test_submit_assignment_student_1(client, h_student_1):
    response = client.post(
        '/student/assignments/submit',
        headers=h_student_1,
        json={
            'id': 4,
            'teacher_id': 2,
            'content': 'ABCD TESTSUBMIT'
            
        })

    assert response.status_code == 200

    data = response.json['data']
    assert data['student_id'] == 1
    assert data['state'] == 'SUBMITTED'
    assert data['teacher_id'] == 2


def test_assignment_resubmit_error(client, h_student_1):
    response = client.post(
        '/student/assignments/submit',
        headers=h_student_1,
        json={
            'id': 2,
            'teacher_id': 2
        })
    error_response = response.json
    assert response.status_code == 400
    assert error_response['error'] == 'FyleError'
    assert error_response["message"] == 'only a draft assignment can be submitted'



def test_submit_assignment_nonexistent_teacher(client, h_student_1):
    response = client.post(
        '/student/assignments/submit',
        headers=h_student_1,
        json={
            'id': 2,
            'teacher_id': 999  # Invalid teacher ID
        })

    assert response.status_code == 400  # Or your custom error code
    data = response.json
    assert data['error'] == 'FyleError' 
    
    
def test_submit_assignment_nonexistent_ID(client, h_student_1):
    response = client.post(
        '/student/assignments/submit',
        headers=h_student_1,
        json={
            'id': 2000,# Invalid ID
            'teacher_id': 2  
        })

    assert response.status_code == 400  
    data = response.json
    assert data['error'] == 'FyleError'      



def test_repost_assignment_student_1(client, h_student_1):
    content = 'ABCD TESTPOST2'

    response = client.post(
        '/student/assignments',
        headers=h_student_1,
        json={
            'content': content
        })

    assert response.status_code == 200

    data = response.json['data']
    assert data['content'] == content
    assert data['state'] == 'DRAFT'
    assert data['teacher_id'] is None

def test_submit_assignment_missing_fields(client, h_student_1):
    response = client.post(
        '/student/assignments/submit',
        headers=h_student_1,
        json={
            'teacher_id': 2
        })
    assert response.status_code == 400
    error_response = response.json
    assert error_response['error'] == 'ValidationError'



def test_post_assignment_student_1_my(client, h_student_1):
    content = 'MY TEST'

    response = client.post(
        '/student/assignments',
        headers=h_student_1,
        json={
            'content': content
        })

    assert response.status_code == 200
    data = response.json['data']
    assert data['content'] == content
    assert data['state'] == 'DRAFT'
    assert data['teacher_id'] is None


def test_post_assignment_student_1_update_my(client, h_student_1):
    content = 'MY TEST UPDATED'

    response = client.post(
        '/student/assignments',
        headers=h_student_1,
        json={
            'id': 7,
            'content': content
        })

    try:
        assert response.status_code == 200
        data = response.json['data']
        assert data['content'] == content
        assert data['state'] == 'DRAFT'
        assert data['teacher_id'] is None
    except AssertionError:
        assert response.status_code == 400
        data = response.json
        assert data['error'] == 'FyleError'
        assert data['message'] == 'only assignment in draft state can be edited'


def test_submit_assignment_student_1_my(client, h_student_1):
    """
    can be failure case: only a draft assignment can be submitted ( an assignment can't be submitted more than once. )
    """
    response = client.post(
        '/student/assignments/submit',
        headers=h_student_1,
        json={
            'id': 7,
            'teacher_id': 1
        })

    try:
        assert response.status_code == 200
        data = response.json['data']
        assert data['student_id'] == 1
        assert data['state'] == 'SUBMITTED'
        assert data['teacher_id'] == 1
    except AssertionError:
        assert response.status_code == 400
        data = response.json
        assert data['error'] == 'FyleError'




    